#include <jni.h>
#include <string>

extern "C"
JNIEXPORT jint JNICALL
Java_com_example_myapplication_MainActivity_addNum(JNIEnv *env, jobject thiz, jint a, jint b) {
    return a + b;
}