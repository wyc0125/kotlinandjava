package com.example.myapplication

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = MyJava()
        val arr = intArrayOf(1, 2, 3, 4, 5, 6)
        val sum = p.addNum(arr)
        val textView = TextView(this)
        textView.append("sum is $sum")
        setContentView(textView)
    }
}